 // Variables for game logic
let flippedCards = [];
let matchedPairs = 0;
const totalPairs = 4;  // Total pairs of artworks and artists
const cards = document.querySelectorAll('.card');
const restartButton = document.getElementById('restart-button');

// Function to handle card flipping
function flipCard() {
  if (flippedCards.length < 2) {
    this.classList.add('flipped');
    flippedCards.push(this);

    if (flippedCards.length === 2) {
      checkMatch();
    }
  }
}

// Function to check if two flipped cards match
function checkMatch() {
  const [firstCard, secondCard] = flippedCards;
  const firstName = firstCard.getAttribute('data-name');
  const secondName = secondCard.getAttribute('data-name');
  
  if (firstName === secondName) {
    matchedPairs++;
    resetFlippedCards();
    if (matchedPairs === totalPairs) {
      alert('You win! All pairs matched.');
    }
  } else {
    setTimeout(() => {
      firstCard.classList.remove('flipped');
      secondCard.classList.remove('flipped');
      resetFlippedCards();
    }, 1000);
  }
}

// Function to reset the flipped cards array
function resetFlippedCards() {
  flippedCards = [];
}

// Function to restart the game
function restartGame() {
  matchedPairs = 0;
  flippedCards = [];
  cards.forEach(card => {
    card.classList.remove('flipped');
  });
  shuffleCards();
}

// Function to shuffle the cards
function shuffleCards() {
  const shuffledCards = Array.from(cards);
  shuffledCards.sort(() => Math.random() - 0.5);
  const container = document.querySelector('.game-container');
  shuffledCards.forEach(card => {
    container.appendChild(card);
  });
}

// Event listeners for each card
cards.forEach(card => {
  card.addEventListener('click', flipCard);
});

// Event listener for restarting the game
restartButton.addEventListener('click', restartGame);

// Initial shuffle of the cards
shuffleCards();
