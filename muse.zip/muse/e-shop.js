    const cart = {
      items: [],
      addItem(product) {
        const existingItem = this.items.find(item => item.id === product.id);
        if (existingItem) {
          existingItem.quantity += 1;
        } else {
          this.items.push({ ...product, quantity: 1 });
        }
        this.updateCartUI();
      },
      removeItem(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        this.updateCartUI();
      },
      getTotalPrice() {
        return this.items.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2);
      },
      updateCartUI() {
        const cartContainer = document.querySelector("#cart-items");
        const totalPrice = document.querySelector("#cart-total");
        cartContainer.innerHTML = "";
        if (this.items.length === 0) {
          cartContainer.innerHTML = "<p>Your cart is empty.</p>";
        } else {
          this.items.forEach(item => {
            const cartItem = document.createElement("div");
            cartItem.classList.add("cart-item");
            cartItem.innerHTML = `
              <div class="cart-item-info">
                <span>${item.name}</span>
                <span>DT ${(item.price * item.quantity).toFixed(2)} (${item.quantity}x)</span>
              </div>
              <button class="btn-remove" data-id="${item.id}">Remove</button>
            `;
            cartContainer.appendChild(cartItem);
          });
        }
        totalPrice.textContent = this.getTotalPrice();
        document.querySelectorAll(".btn-remove").forEach(button => {
          button.addEventListener("click", event => {
            const productId = parseInt(event.target.getAttribute("data-id"), 10);
            this.removeItem(productId);
          });
        });
      }
    };

    document.querySelectorAll(".add-to-cart").forEach(button => {
      button.addEventListener("click", event => {
        const productCard = event.target.closest(".product-card");
        const product = {
          id: parseInt(event.target.getAttribute("data-id"), 10),
          name: productCard.querySelector("h3").textContent,
          price: parseFloat(event.target.getAttribute("data-price"))
        };
        cart.addItem(product);
      });
    });

    const cartModal = document.querySelector("#cart-modal");
    const openCartButton = document.querySelector("#open-cart");
    const closeCartButton = document.querySelector("#close-cart");
    const checkoutButton = document.querySelector("#checkout-button");

    openCartButton.addEventListener("click", () => {
      cartModal.style.display = "block";
    });

    closeCartButton.addEventListener("click", () => {
      cartModal.style.display = "none";
    });


    cart.updateCartUI();